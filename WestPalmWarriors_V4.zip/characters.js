const fighters=[
'95 Rich',
'Dragon Master',
'Moon Dancer',
'Titan X'
];