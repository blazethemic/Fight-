let level=0;
let time=180;

const start=document.getElementById('startBtn');
const play=document.getElementById('playBtn');
const fightersBox=document.getElementById('fighters');

fighters.forEach(name=>{
const div=document.createElement('div');
div.className='card';
div.innerHTML=name;
fightersBox.appendChild(div);
});

start.onclick=()=>{
menu.classList.add('hidden');
characterScreen.classList.remove('hidden');
};

play.onclick=()=>{
characterScreen.classList.add('hidden');
hud.classList.remove('hidden');
document.getElementById('city').innerHTML=cities[level];

setInterval(()=>{
time--;
document.getElementById('timer').innerHTML=time;

if(time<=0){
alert('Level Complete');
time=180;
level++;

if(level>=cities.length){
alert('Champion!');
location.reload();
return;
}

document.getElementById('city').innerHTML=cities[level];
}
},1000);
};