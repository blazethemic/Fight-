Upload every file to GitHub.
Go to Settings > Pages > Deploy from Main branch.