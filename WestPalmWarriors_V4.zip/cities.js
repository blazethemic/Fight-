const cities=[
'West Palm Beach',
'Hong Kong',
'Las Vegas',
'New York City'
];